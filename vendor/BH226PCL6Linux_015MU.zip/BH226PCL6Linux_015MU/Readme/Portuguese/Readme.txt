KONICA MINOLTA bizhub 206/226/246 Linux Driver da Impressora
============================================
Ver. 1.0.0

-Se a vers�o do CUPS for anterior a GhostScript 8.70, a predefini��o de papel � ignorada e � predefinido "Carta".

-Quando a instala��o do driver estiver completa, poder�o ocorrer os seguintes problemas se alterar o idioma para Turco:
 Idioma n�o altera se alterar o idioma em Turco.
 N�o ser�o exibidos "Detalhes da impressora" no ecr� de defini��o da impressora do SO.Adicionalmente, os detalhes da impressora n�o aparecem no ecr� de defini��es do browser do CUPS.

-O n.� de c�pias pode ser configurado no SO ou na aplica��o.
Se a defini��o de c�pias da aplica��o for > 1, o n.� de c�pias a ser impresso seguir� a defini��o da aplica��o.
Se a defini��o de c�pias da aplica��o for = 1, o n.� de c�pias a ser impresso seguir� a configura��o do SO.

-No driver Linux PCL, os trabalhos do Libreoffice poder�o n�o ser impressos correctamente se for utilizado Suse x32.

============================================
Copyright(C) 2015 KONICA MINOLTA, INC.
Reservados todos os direitos.


