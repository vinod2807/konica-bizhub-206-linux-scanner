KONICA MINOLTA bizhub 206/226/246 Linux Printer Driver
============================================
Ver. 1.0.0

-If CUPS version is older than GhostScript 8.70, the default paper setting is ignored and "Letter" will set as default.

-When the driver installation is complete, the following problems may occur when you change the language to Turkish:
  Language does not change if you change the language in Turkish.
  "Printer-details" will not be displayed on the OS printer setting screen. In addition, the printer details do not appear in the browser settings screen of CUPS.
When this happens you can solve the problem by changing the language selection of FireFox.

-The number of copies can be set in the OS or in the application.
If the application copies setting is > 1, the number of copies to be printed will follow the setting of the application.
If the application copies setting = 1, the number of copies to be printed will follow the configuration of the OS.

-In the Linux PCL driver when using Suse x32, jobs from Libreoffice may not print correctly.

============================================
Copyright(C) 2015 KONICA MINOLTA, INC.
All rights reserved.

