Pilote d'imprimante KONICA MINOLTA bizhub 206/226/246 pour Linux
=============================================================
Ver. 1.0.0

-Si la version de CUPS est ant�rieure � GhostScript 8.70, le r�glage papier par d�faut est ignor� et � Letter � sera r�gl� par d�faut.

-Lorsque l'installation du pilote est termin�e, les probl�mes suivants peuvent survenir lorsque vous choisissez le turc comme langue :
 La langue ne change pas si vous choisissez le turc comme langue.
 Les � d�tails de l'imprimante � ne s'afficheront pas sur l'�cran de r�glage de l'imprimante du SE. De plus, les d�tails de l'imprimante n'appara�tront pas dans l'�cran des r�glages du navigateur de CUPS.
Dans ce cas, vous pouvez r�soudre le probl�me en changeant la s�lection de langue de Firefox.

-Le nombre de copies peut �tre r�gl� dans le SE ou dans l'application.
Si le r�glage des copies de l'application est > 1, le nombre de copies � imprimer sera identique au r�glage de l'application.
Si le r�glage des copies de l'application est = 1, le nombre de copies � imprimer sera identique � la configuration du SE.

-Dans le pilote PCL Linux en cas d'utilisation de Suse x32, les t�ches depuis Libreoffice peuvent ne pas s'imprimer correctement.

=============================================================
Copyright(C) 2015 KONICA MINOLTA, INC.
Tous droits r�serv�s.
