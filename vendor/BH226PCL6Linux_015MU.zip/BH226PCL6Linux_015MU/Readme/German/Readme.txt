KONICA MINOLTA bizhub 206/226/246 Linux-Druckertreiber
============================================
Ver. 1.0.0

-Wenn die CUPS-Version �lter als GhostScript 8.70 ist, wird die Standardpapiereinstellung ignoriert und "Letter" als Standard festgelegt.

-Nach dem Abschluss der Treiberinstallation k�nnen die folgenden Probleme auftreten, wenn Sie die Sprache auf T�rkisch umstellen:
 Die Sprache wird nicht ge�ndert, wenn Sie die Sprache auf T�rkisch umstellen.
 "Druckerdetails" wird nicht im betriebssystemspezifischen Bildschirm f�r die Druckeinstellungen angezeigt. Au�erdem erscheinen die Druckerdetails nicht im Browser-Einstellungsbildschirm von CUPS.
In diesem Fall k�nnen Sie das Problem beheben, indem Sie die Sprachauswahl von Firefox �ndern.

-Die Anzahl der Kopien kann im Betriebssystem oder in der Anwendung festgelegt werden.
Wenn in der anwendungsspezifischen Kopiereinstellung eine Anzahl > 1 angegeben ist, gilt f�r die Anzahl der Kopien die Einstellung der Anwendung.
Wenn in der anwendungsspezifischen Kopiereinstellung die Anzahl = 1 angegeben ist, gilt f�r die Anzahl der Kopien die Konfiguration des Betriebssystems.

-Bei Verwendung des Linux PCL-Treibers unter Suse x32 werden Jobs von Libreoffice unter Umst�nden nicht ordnungsgem�� gedruckt.

============================================
Copyright(C) 2015 KONICA MINOLTA, INC.
Alle Rechte vorbehalten.
