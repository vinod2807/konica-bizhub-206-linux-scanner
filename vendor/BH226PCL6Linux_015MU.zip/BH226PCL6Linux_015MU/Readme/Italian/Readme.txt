Driver stampante KONICA MINOLTA bizhub 206/226/246 per Linux
============================================
Ver. 1.0.0

-Se la versione CUPS � pi� vecchia di GhostScript 8.70, l'impostazione carta predefinita � ignorata e "Letter" sar� impostato come predefinito.

-Quando l'installazione del driver � stata completata, possono verificarsi i seguenti problemi quando si imposta la lingua su turco:
 La lingua non cambia se la si imposta su turco.
 "Dettagli-stampante" non sar� visualizzato nella schermata di impostazione della stampante OS. Inoltre, i dettagli stampanti non sono visualizzati nella schermata delle impostazioni del browser di CUPS.
Quando ci� accade, � possibile risolvere il problema cambiando la selezione della lingua di Firefox.

-Il numero di copie pu� essere impostato nell'OS o nell'applicazione.
Se l'impostazione delle copie dell'applicazione � > 1, il numero di copie da stampare seguir� l'impostazione dell'applicazione.
Se l'impostazione delle copie dell'applicazione � = 1, il numero di copie da stampare seguir� la configurazione dell'OS.

-Nel driver Linux PCL quando si usa Suse x32, i lavori da Libreoffice potrebbero non essere stampati correttamente.

============================================
Copyright(C) 2015 KONICA MINOLTA, INC.
Tutti i diritti riservati.
