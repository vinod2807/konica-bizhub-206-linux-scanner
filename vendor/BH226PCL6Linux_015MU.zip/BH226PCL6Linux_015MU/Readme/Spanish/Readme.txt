Controlador de Linux para la impresora bizhub 206/226/246 KONICA MINOLTA 
============================================
Ver. 1.0.0

- Si la versi�n de CUPS es anterior a GhostScript 8.70, se ignora el ajuste de papel predeterminado y el ajuste "Carta" se define como predeterminado.

- Al finalizar la instalaci�n del controlador, es posible que se produzcan los siguientes problemas al cambiar el idioma al turco:
 El idioma no se cambia al intentar cambiar el idioma en turco.
 Los "Detalles de impresora" no se muestran en la pantalla de configuraci�n de impresora del sistema operativo. Adem�s, los detalles de la impresora no aparecen en la pantalla de configuraci�n del explorador de CUPS.
Si pasa esto, se puede resolver el problema cambiando la selecci�n de idioma de Firefox.

- El n�mero de copias se puede ajustar en el sistema operativo o en la aplicaci�n.
Si la configuraci�n de copia de la aplicaci�n es > 1, el n�mero de copias a imprimir se regir� por el ajuste de la aplicaci�n.
Si la configuraci�n de copia de la aplicaci�n es = 1, el n�mero de copias a imprimir se regir� por la configuraci�n del sistema operativo.

- En el controlador PCL de Linux al utilizar Suse x32, es posible que las tareas de Libreoffice no se impriman correctamente.

============================================
Copyright(C) 2015 KONICA MINOLTA, INC.
Se reservan todos los derechos.
